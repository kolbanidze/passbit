from setuptools import setup

setup(
    name='PassBit',
    version='1.0',
    description='PassBit',
    url='https://github.com/kolbanidze/passbit',
    author='Kolbanidze',
    # author_email='shudson@anl.gov',
    license='GNU GPL v3',
    packages=['passbit'],
    install_requires=['argon2-cffi',
                      'CTkMessagebox',
                      'customtkinter',
                      'PyCryptodome',
                      'pyotp',
                      'pyperclip',
                      'Requests'],
)
